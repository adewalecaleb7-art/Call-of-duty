package com.calebgraphics.codbooster

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.os.PowerManager
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : androidx.appcompat.app.AppCompatActivity() {
    private val bg = Color.rgb(5, 10, 15)
    private val card = Color.rgb(12, 25, 35)
    private val yellow = Color.rgb(255, 212, 0)
    private val white = Color.WHITE
    private val green = Color.rgb(45, 220, 130)

    private lateinit var status: TextView
    private lateinit var ram: TextView
    private lateinit var battery: TextView
    private lateinit var temp: TextView
    private lateinit var network: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshStats()
    }

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(16, 10, 16, 10)
        }
    }

    private fun cardView(child: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(card)
            addView(child)
        }
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 24)
            setBackgroundColor(bg)
        }
        scroll.addView(root)

        root.addView(tv("COD", 32f, white, true))
        root.addView(tv("GAME BOOSTER", 25f, yellow, true))
        root.addView(tv("LESS LAG  ⚡  BETTER FPS  ⚡  SMOOTHER GAMEPLAY", 12f, Color.LTGRAY))

        val boost = Button(this).apply {
            text = "⚡  BOOST COD NOW"
            textSize = 20f
            setTextColor(Color.BLACK)
            setBackgroundColor(yellow)
            setOnClickListener { boostCod() }
        }
        val lp = LinearLayout.LayoutParams(-1, 80)
        lp.setMargins(0, 20, 0, 18)
        root.addView(boost, lp)

        status = tv("READY TO BOOST", 15f, green, true)
        status.gravity = Gravity.CENTER
        root.addView(status)

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ram = tv("", 16f, white, true)
        battery = tv("", 16f, white, true)
        temp = tv("", 16f, white, true)
        network = tv("", 16f, white, true)

        val row1 = LinearLayout(this)
        row1.addView(cardView(ram), LinearLayout.LayoutParams(0, 105, 1f).apply { setMargins(0, 8, 6, 8) })
        row1.addView(cardView(battery), LinearLayout.LayoutParams(0, 105, 1f).apply { setMargins(6, 8, 0, 8) })
        grid.addView(row1)

        val row2 = LinearLayout(this)
        row2.addView(cardView(temp), LinearLayout.LayoutParams(0, 105, 1f).apply { setMargins(0, 8, 6, 8) })
        row2.addView(cardView(network), LinearLayout.LayoutParams(0, 105, 1f).apply { setMargins(6, 8, 0, 8) })
        grid.addView(row2)
        root.addView(grid)

        val launch = Button(this).apply {
            text = "🎮  LAUNCH CALL OF DUTY MOBILE"
            textSize = 16f
            setOnClickListener { launchCod() }
        }
        root.addView(launch, LinearLayout.LayoutParams(-1, 62).apply { setMargins(0, 18, 0, 8) })

        val refresh = Button(this).apply {
            text = "↻  REFRESH PERFORMANCE"
            setOnClickListener { refreshStats() }
        }
        root.addView(refresh)

        root.addView(tv(
            "\nWHAT BOOST DOES\n• Refreshes performance information\n• Opens COD Mobile directly\n• Monitors RAM, battery, temperature and network\n• Keeps the booster lightweight\n\nNOTE\nAndroid does not allow ordinary apps to magically increase physical RAM or force a higher FPS than the game/device supports.",
            13f, Color.LTGRAY
        ))

        setContentView(scroll)
    }

    private fun boostCod() {
        status.text = "BOOST PREPARING…"
        refreshStats()
        window.decorView.postDelayed({
            status.text = "COD IS READY  ✓"
            launchCod()
        }, 700)
    }

    private fun launchCod() {
        val packages = listOf(
            "com.activision.callofduty.shooter",
            "com.garena.game.codm",
            "com.activision.callofduty.warzone"
        )
        for (pkg in packages) {
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                status.text = "LAUNCHING COD…"
                startActivity(intent)
                return
            }
        }
        Toast.makeText(this, "Call of Duty Mobile was not found. Install COD Mobile first.", Toast.LENGTH_LONG).show()
    }

    private fun refreshStats() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val availGb = info.availMem / 1024.0 / 1024.0 / 1024.0
        val totalGb = info.totalMem / 1024.0 / 1024.0 / 1024.0
        ram.text = "RAM\n%.1f / %.1f GB free".format(Locale.US, availGb, totalGb)

        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        battery.text = "BATTERY\n$pct%"

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val thermal = if (android.os.Build.VERSION.SDK_INT >= 29) {
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Warm"
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
                PowerManager.THERMAL_STATUS_SEVERE -> "High"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
                else -> "Unknown"
            }
        } else "Unavailable"
        temp.text = "THERMAL\n$thermal"

        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(n)
        val type = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi‑Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobile data"
            else -> "Offline"
        }
        network.text = "NETWORK\n$type"
    }
}
